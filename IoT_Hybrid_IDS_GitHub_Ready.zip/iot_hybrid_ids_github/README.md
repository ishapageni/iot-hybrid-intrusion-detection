# Explainable Hybrid IoT Intrusion Detection and Risk Prioritization

Research implementation accompanying the paper in `paper/main.tex`.

## What this repository contains

- `notebooks/iot_hybrid_intrusion_detection.ipynb`: the executed Jupyter notebook used for the reported experiment.
- `paper/main.tex`: Springer LNCS LaTeX source for Overleaf.
- `requirements.txt`: Python dependencies.
- `outputs/` and `models/`: directories for generated outputs and model artefacts (generated locally; not committed by default).

## Experiment summary

Dataset: CICIoT2023 CSV files. The notebook processes files in chunks and samples up to 200,000 benign rows and 10,000 rows per attack category. It retains the source CSV path as a group identifier and excludes it from model features. GroupShuffleSplit separates source CSVs into fit, calibration, and test groups.

Reported run:

| Model | Accuracy | Attack precision | Attack recall | Attack F1 | FPR |
|---|---:|---:|---:|---:|---:|
| Random Forest | 88.63% | 85.76% | 86.68% | 86.22% | 10.02% |
| Isolation Forest | 76.51% | 96.09% | 44.59% | 60.91% | 1.26% |
| Hybrid OR | 88.43% | 85.26% | 86.81% | 86.03% | 10.45% |

The sampling is category-capped, not prevalence-preserving. The metrics must not be interpreted as deployment performance at natural IoT traffic prevalence. The source-file split reduces leakage within a CSV but does not guarantee capture-, device-, or campaign-level independence.

## Setup

1. Download the official CICIoT2023 CSV dataset from: https://www.unb.ca/cic/datasets/iotdataset-2023.html
2. Extract it so the notebook can find `data/CSV/<category>/*.csv` under the project root. For example:

```text
project/
  data/
    CSV/
      Benign_Final/
      DDoS-UDP_Flood/
      ...
  notebooks/
  paper/
```

3. Create a Python 3.11 environment and install dependencies:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

4. Launch Jupyter:

```bash
jupyter notebook
```

5. Open the notebook. Because it uses `Path.cwd()/data`, run it with the project root as the working directory (or adjust `DATA_DIR` to the actual dataset location). Run all cells from top to bottom.

## Overleaf

Create a new Overleaf project, upload `paper/main.tex`, choose the `pdfLaTeX` compiler, and compile. The document uses the Springer LNCS class (`llncs`). If Overleaf does not already provide `llncs.cls`, upload the official Springer LNCS template files from the Springer/Overleaf template bundle.

Replace `[Author Name]`, `[Department and Institution]`, and `[email address]` before submission. Check the target venue's required Springer class: LNCS is a Springer conference proceedings format, not a universal Springer journal template.

## GitHub publishing

Create an empty repository on GitHub, then from this folder run:

```bash
git init
git add README.md requirements.txt .gitignore paper notebooks
# Inspect staged files before committing
git status
git commit -m "Add hybrid IoT intrusion detection research project"
git branch -M main
git remote add origin https://github.com/<YOUR-USERNAME>/<YOUR-REPOSITORY>.git
git push -u origin main
```

Do not upload the CICIoT2023 dataset itself unless its licence/terms permit redistribution. Do not commit large generated model files or raw sampled data by default.

## Reproducibility and interpretation notes

- The notebook's test partition contains 96,066 records from 47 source CSV groups; fit has 254,594 rows from 215 groups; calibration has 136,431 rows from 47 groups.
- By source-file group counts, the split is 69.6% / 15.2% / 15.2%; by row counts it is 52.3% / 28.0% / 19.7%. Report actual row counts in any paper.
- The hybrid OR rule increases recall by only 0.13 percentage points over RF and increases FPR by 0.43 points. Do not claim that hybrid is universally superior.
- RF ROC-AUC = 0.9559 and PR-AUC = 0.9479. IF and Hybrid AUC are not reported because the notebook evaluates them as binary decisions rather than continuous scores.
- Risk score `100 * (0.6 * RF_probability + 0.4 * normalized_anomaly_score)` is a heuristic triage ranking, not a calibrated probability of compromise.
